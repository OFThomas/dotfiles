"""Mixed metaphors."""
