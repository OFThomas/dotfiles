"""Cursing."""
