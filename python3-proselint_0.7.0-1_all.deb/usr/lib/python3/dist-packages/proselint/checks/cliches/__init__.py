"""Avoid cliches."""
