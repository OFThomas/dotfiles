"""Hyperbole."""
