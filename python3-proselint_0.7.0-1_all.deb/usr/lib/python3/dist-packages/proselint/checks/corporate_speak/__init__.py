u"""Corporate-speak."""
